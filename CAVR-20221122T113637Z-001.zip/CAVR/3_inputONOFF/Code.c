//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
#include <mega328p.h>  
#include <delay.h>

unsigned char i;
unsigned char nutSW1, nutSW1truoc, nutSW3, nutSW3truoc;
unsigned char demNut1;

#define La PORTD.6  
#define Lg PORTD.5
#define Lb PORTB.0 
#define Lc PORTB.1 
#define Ld PORTB.2 
#define Le PORTB.3 
#define Lf PORTB.4 
               
void hienthiLED(unsigned char so)
{
    if(so==0) {La=1;Lb=1;Lc=1;Ld=1;Le=1;Lf=1;Lg=0;}
    if(so==1) {La=0;Lb=1;Lc=1;Ld=0;Le=0;Lf=0;Lg=0;}
    if(so==2) {La=1;Lb=1;Lc=0;Ld=1;Le=1;Lf=0;Lg=1;}
    if(so==3) {La=1;Lb=1;Lc=1;Ld=1;Le=0;Lf=0;Lg=1;}
    if(so==4) {La=0;Lb=1;Lc=1;Ld=0;Le=0;Lf=1;Lg=1;}
    if(so==5) {La=1;Lb=0;Lc=1;Ld=1;Le=0;Lf=1;Lg=1;}
    if(so==6) {La=1;Lb=0;Lc=1;Ld=1;Le=1;Lf=1;Lg=1;}
    if(so==7) {La=1;Lb=1;Lc=1;Ld=0;Le=0;Lf=0;Lg=0;}
    if(so==8) {La=1;Lb=1;Lc=1;Ld=1;Le=1;Lf=1;Lg=1;}
    if(so==9) {La=1;Lb=1;Lc=1;Ld=1;Le=0;Lf=1;Lg=1;} 
    
    if(so==16) {La=0;Lb=0;Lc=0;Ld=0;Le=0;Lf=0;Lg=0;}   
} 

void main(void)
{
// Crystal Oscillator division factor: 1
#pragma optsize-
CLKPR=(1<<CLKPCE);
CLKPR=(0<<CLKPCE) | (0<<CLKPS3) | (0<<CLKPS2) | (0<<CLKPS1) | (0<<CLKPS0);
#ifdef _OPTIMIZE_SIZE_
#pragma optsize+
#endif

DDRD.6=1; //output 
DDRD.5=1; //output
DDRB.0=1; //output
DDRB.1=1; //output
DDRB.2=1; //output
DDRB.3=1; //output  
DDRB.4=1; //output

DDRD.4=0; //input
PORTD.4=1; //co R_pullup 
 
DDRD.7=0; //input
PORTD.7=1; //co R_pullup

while (1)
{
    nutSW1truoc=nutSW1; nutSW1=PIND.4; 
    nutSW3truoc=nutSW3; nutSW3=PIND.7; 
    
    if(nutSW1truoc==1 && nutSW1==0) {
        demNut1++;
        if(demNut1>9) {demNut1=0;} 
        hienthiLED(demNut1);
    }   
    if(nutSW3==0) {hienthiLED(16);}  
    delay_ms(10); 
}
}
//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx