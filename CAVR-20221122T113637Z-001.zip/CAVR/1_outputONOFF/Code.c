//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
#include <mega328p.h>  
#include <delay.h>

void main(void)
{
// Crystal Oscillator division factor: 1
#pragma optsize-
CLKPR=(1<<CLKPCE);
CLKPR=(0<<CLKPCE) | (0<<CLKPS3) | (0<<CLKPS2) | (0<<CLKPS1) | (0<<CLKPS0);
#ifdef _OPTIMIZE_SIZE_
#pragma optsize+
#endif

DDRD.6 = 1; //D6 output

while (1)
{
    PORTD.6 = 1; //muc CAO
    delay_ms(500); 
    PORTD.6 = 0; //muc THAP 
    delay_ms(500);    
}
}
//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx